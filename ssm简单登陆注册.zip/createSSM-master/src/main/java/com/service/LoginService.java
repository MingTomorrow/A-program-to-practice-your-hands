package com.service;

import com.bean.UserInfo;

public interface LoginService {

    public UserInfo getUserInfoIsExists(UserInfo userInfo);
}
