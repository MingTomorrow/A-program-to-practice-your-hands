package com.bean;

import lombok.Data;

@Data
public class UserInfo {
    private String userName;
    private String password;
    private String Msg;
    private String code;
    private String sex;
    private String name;
    private String lastLoginTime;
    private String createTime;
    private String updateTime;
    private String secondPassword;


}
